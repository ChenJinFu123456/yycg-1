create procedure insert_table(insert_num) is
/*
       功能：先删除表，在插入表数据


       
*/
 V_insert_num number;
 v_insert_num:=insert_num;
 insert_sql nvarchar2(1000);
 delete_sql nvarchar2(1000);
begin
            delete_sql:='delete from hc.teach';
            execute delete_sql;
            commit;
            insert_sql:='
            insert into hc.teach(ID,
                      NAME,
                      AGE,
                      SEX,
                      CLASS,
                      JOB,
                      REMARK
                      )
                      select rownum,
                      ''张三'',
                      ''20'',
                      ''男'',
                      ''软件工程'',
                      ''辅导员'',
                      ''啊哈哈'' 
                      from dual connect by rownum<'||V_insert_num||'
  ';
  execute insert_sql

  
end ;
/

