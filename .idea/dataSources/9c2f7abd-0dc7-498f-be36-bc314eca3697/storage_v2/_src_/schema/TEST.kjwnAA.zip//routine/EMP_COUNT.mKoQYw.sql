create procedure emp_count is
sum_count NUMBER;
begin
select count(*) into sum_count from emp;
dbms_output.put_line(sum_count);
end;
/

