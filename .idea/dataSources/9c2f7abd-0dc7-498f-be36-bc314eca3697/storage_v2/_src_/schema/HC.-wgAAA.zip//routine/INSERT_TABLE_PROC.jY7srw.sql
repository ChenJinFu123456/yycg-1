create PROCEDURE    INSERT_TABLE_PROC(INSERT_NUM NUMBER) IS
/*
       功能：先删除表数据，在插入表数据


       
*/
 V_INSERT_NUM NUMBER;
 INSERT_SQL VARCHAR2(1000);
 DELETE_SQL VARCHAR2(1000);
 err_name varchar2(100);
BEGIN
            V_INSERT_NUM:=INSERT_NUM;
            err_name:='HC.INSERT_TABLE_PROC';
            
            DELETE_SQL:='delete from hc.teach';
            EXECUTE IMMEDIATE DELETE_SQL;
            COMMIT;
            DELETE_SQL:='delete from hc.student';
            EXECUTE IMMEDIATE DELETE_SQL;
            COMMIT;
            INSERT_SQL:='
            insert into hc.teach(ID,
                      NAME,
                      AGE,
                      SEX,
                      CLASS,
                      JOB,
                      REMARK
                      )
                      select rownum,
                      ''张三'',
                      ''20'',
                      case when mod(rownum,2)=0 then ''男''
                        else ''女'' end,
                      case when rownum<=300 then ''信息与工程学院''
                           when rownum<=500 then ''动漫学院''
                           when rownum<=800 then ''土木院''
                           when rownum<=900 then ''商学院''
                           else ''电院'' end,
                      ''辅导员'',
                      ''啊哈哈'' 
                      from dual connect by rownum<='||V_INSERT_NUM/100
  ;
   EXECUTE IMMEDIATE INSERT_SQL;
   COMMIT;
           INSERT_SQL:='
                    insert into hc.student(ID,
                      NAME,
                      AGE,
                      SEX,
                      CLASS,
                      JOB,
                      REMARK
                      )
                      select rownum,
                      ''张三'',
                      ''20'',
                    case when mod(rownum,2)=0 then ''男''
                        else ''女'' end,
                      case when rownum<=30000 then ''信息与工程学院''
                           when rownum<=50000 then ''动漫学院''
                           when rownum<=80000 then ''土木院''
                           when rownum<=90000 then ''商学院''
                           else ''电院'' end,
                      ''班长'',
                      ''啊哈哈'' 
                      from dual connect by rownum<='||V_INSERT_NUM
              ;
   EXECUTE IMMEDIATE INSERT_SQL;
   COMMIT;
      INSERT_SQL:='insert into hc.log(err_name,err_remark)
                               values (:1,:2)';
      EXECUTE IMMEDIATE INSERT_SQL
              using err_name,dbms_utility.format_error_stack;
       COMMIT;
   exception 
     when others then 
      INSERT_SQL:='insert into hc.log(err_name,err_remark)
                               values (:1,:2)';
      EXECUTE IMMEDIATE INSERT_SQL
              using err_name,dbms_utility.format_error_stack;
       COMMIT;
       rollback;
END INSERT_TABLE_PROC;
/

