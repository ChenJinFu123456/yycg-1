create view MAN_TEACH as
  select "ID","NAME","AGE","SEX","CLASS","JOB","REMARK","CRE_DATE" from hc.teach t where t.sex='男'
with read only
/

